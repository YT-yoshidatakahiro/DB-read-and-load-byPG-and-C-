﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.Odbc;

namespace kadai3_1
{
    public partial class pqsldb : Form
    {
        public string pgsqlstr1 =
                                     "Dsn=PostgreSQL35Wkadai64;" +
                                     "Server =localhost;" +
                                     "Port = 5432;" +
                                     "User id=postgres;" +
                                     "Pwd=postgres;" +
                                     "DataBase=kaiin";

        public string[] listname ={"id", "gender", "job", "name"};

        //テーブルの格納
        public DataSet pgconn5 = new DataSet();

        //データセットへの格納
        DataTable pgconn4 = new DataTable();

        //DBとのコネクション
        public OdbcConnection pgconn1 = new OdbcConnection();

        public OdbcCommand pgconn2 = new OdbcCommand();

        public OdbcDataAdapter pgconn3 = new OdbcDataAdapter();
        
        //SQL利用分
            //メイン画面でのSQL
            public string sqlac1 = "select * from kaiin order by id asc";
        
            //追加画面・変更画面共通のSQL
            public string sqlac11 = "select * from gender";

            public string sqlac111 = "select * from job";

            //追加画面でのSQL
            public string sqlac1111 = @"select max(id) from kaiin";

            public string sqlac11111 = @"insert into kaiin(id, gender,job,name) values(?,?,?,?)";

            public string sqlac111111 = @"delete from kaiin where id = ?";

            //変更画面でのSQL
            public string sqlac1111111 = @"update kaiin set gender =?, job = ?, name =? where id =? ";


        /// <summary>
        ///mainテーブル
        /// </summary>
        public void test()
        {
            if (pgconn5.Tables["maindb"] == null)
            {
                //DatasetへメインDB格納
                pgconn1 = new OdbcConnection();

                pgconn2 = new OdbcCommand();

                pgconn3 = new OdbcDataAdapter();

                pgconn4.TableName = "maindb";

                pgconn5.Tables.Add(pgconn4);

                pgconn1.ConnectionString = pgsqlstr1;

                pgconn2.CommandText = sqlac1;

                pgconn2.Connection = pgconn1;

                pgconn3.SelectCommand = pgconn2;

                try
                {
                    pgconn3.Fill(pgconn5.Tables["maindb"]);

                }
                catch (Exception)
                {
                    MessageBox.Show("メインテーブルとの接続確認");
                }
                dGV.RowCount = pgconn5.Tables["maindb"].Rows.Count + 1;

                for (int i = 0; i < pgconn5.Tables["maindb"].Rows.Count; i++)
                {
                    for (int j = 0; j < listname.Length; j++)
                    {
                        var maindat1 = pgconn5.Tables["maindb"].Rows[i][j];

                        dGV.Rows[i].Cells[j].Value = maindat1;
                    }

                    //インデックス
                    dGV.Rows[i].HeaderCell.Value = (i + 1).ToString();
                }
            }
            else if (!(pgconn5.Tables["maindb"] == null))
            {
                return;
            }
        }

        /// <summary>
        /// genderテーブル
        /// </summary>
        public void test1()
        {
            pgconn1 = new OdbcConnection();

            pgconn2 = new OdbcCommand();

            pgconn3 = new OdbcDataAdapter();

            pgconn4 = new DataTable();

            //Datasetへ性別テーブル格納
            pgconn4.TableName = "genderdb";

            pgconn5.Tables.Add(pgconn4);

            pgconn1.ConnectionString = pgsqlstr1;

            pgconn2.CommandText = sqlac11;

            pgconn2.Connection = pgconn1;

            pgconn3.SelectCommand = pgconn2;
            try
            {
                pgconn3.Fill(pgconn5.Tables["genderdb"]);
            }
            catch (Exception)
            {
                MessageBox.Show("性別テーブルとの接続確認");
            }
        }

        /// <summary>
        /// jobテーブル
        /// </summary>
        public void test2()
        {
            pgconn1 = new OdbcConnection();

            pgconn2 = new OdbcCommand();

            pgconn3 = new OdbcDataAdapter();

            pgconn4 = new DataTable();

            //Datasetへ職業テーブル格納
            pgconn4.TableName = "jobdb";

            pgconn5.Tables.Add(pgconn4);

            pgconn1.ConnectionString = pgsqlstr1;

            pgconn2.CommandText = sqlac111;

            pgconn2.Connection = pgconn1;

            pgconn3.SelectCommand = pgconn2;

            try
            {
                pgconn3.Fill(pgconn5.Tables["jobdb"]);
            }
            catch (Exception)
            {
                MessageBox.Show("職業テーブルとの接続確認");
            }
        }
        /// <summary>
        /// 追加画面での番号
        /// </summary>
        public string addNo;
        public void test3()
        {
            pgconn1 = new OdbcConnection();

            pgconn2 = new OdbcCommand();

            pgconn3 = new OdbcDataAdapter();

            //番号の格納
            pgconn1.ConnectionString = pgsqlstr1;

            pgconn2.CommandText = sqlac1111;

            pgconn2.Connection = pgconn1;

            pgconn3.SelectCommand = pgconn2;

             //追加画面番号

            pgconn1.Open();

            addNo = Convert.ToString(Convert.ToInt32(pgconn2.ExecuteScalar()) + 1);

            pgconn1.Close();
        }

        /// <summary>
        /// 追加画面での追加実行
        /// </summary>
        public void test4()
        {
            //グリッドビューのデータをSQLへ
            pgconn1 = new OdbcConnection();

            pgconn2 = new OdbcCommand();

            pgconn3 = new OdbcDataAdapter();

            //番号の格納
            pgconn1.ConnectionString = pgsqlstr1;

            pgconn2.CommandText = sqlac11111;

            pgconn2.Connection = pgconn1;

            pgconn3.SelectCommand = pgconn2;

            pgconn2.Parameters.Add(new OdbcParameter("@id",     dGV[0,dGV.Rows.Count - 2].Value));
                                                                                                          
            pgconn2.Parameters.Add(new OdbcParameter("@gender",  dGV[1,dGV.Rows.Count - 2].Value));
                                                                                                          
            pgconn2.Parameters.Add(new OdbcParameter("@job",     dGV[2,dGV.Rows.Count - 2].Value));
                                                                                                          
            pgconn2.Parameters.Add(new OdbcParameter("@name",   dGV[3, dGV.Rows.Count - 2].Value));

            pgconn3.Update(pgconn5.Tables["maindb"]);

            pgconn1.Open();

            pgconn2.ExecuteNonQuery();

            pgconn1.Close();
        }

        /// <summary>
        ///削除画面での登録削除 
        /// </summary>
        public void test5()
        {
            delForm maintodel1 = new delForm();

            //入力番号の削除

            //グリッドビューのデータをSQLへ
            pgconn1 = new OdbcConnection();

            pgconn2 = new OdbcCommand();

            pgconn3 = new OdbcDataAdapter();

            //番号の格納
            pgconn1.ConnectionString = pgsqlstr1;

            pgconn2.CommandText = sqlac111111;

            pgconn2.Connection = pgconn1;

            pgconn3.SelectCommand = pgconn2;

            pgconn2.Parameters.Add(new OdbcParameter("@id", dGV[0, Convert.ToInt32(maintodel1.delnum)].Value));

            pgconn1.Open();

            pgconn2.ExecuteNonQuery();

            pgconn1.Close();
        }

        /// <summary>
        /// 変更画面での変更登録
        /// </summary>

        public void test6()
        {
            changeform maintochng1 = new changeform();

            pgconn1 = new OdbcConnection();

            pgconn2 = new OdbcCommand();

            pgconn3 = new OdbcDataAdapter();

            //番号の格納
            pgconn1.ConnectionString = pgsqlstr1;

            pgconn2.CommandText = sqlac1111111;

            pgconn2.Connection = pgconn1;

            pgconn3.SelectCommand = pgconn2;

            pgconn2.Parameters.Add(new OdbcParameter("@gender", dGV[1, Convert.ToInt32(maintochng1.chngnum)].Value));

            pgconn2.Parameters.Add(new OdbcParameter("@job", dGV[2, Convert.ToInt32(maintochng1.chngnum)].Value));

            pgconn2.Parameters.Add(new OdbcParameter("@name", dGV[3, Convert.ToInt32(maintochng1.chngnum)].Value));

            pgconn2.Parameters.Add(new OdbcParameter("@id", dGV[0, Convert.ToInt32(maintochng1.chngnum)].Value ));

            pgconn1.Open();

            pgconn2.ExecuteNonQuery();

            pgconn1.Close();
        }

        /// <summary>
        /// iniファイルからＤＢパスへのアクセス
        /// </summary>
        public pqsldb()
        {
            InitializeComponent();

            dGV.AllowUserToAddRows = true;

            ControlBox = false;
        }
        /// <summary>
        ///postgresODBC経由での接続設定:データの自動読み込み
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pqsldb_Load(object sender, EventArgs e)
        {
            test();
        }

        /// <summary>
        /// 追加フォームへ移動
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAdd1_Click(object sender, EventArgs e)
        {
            this.Visible = false;

            //追加画面
            addform maintoadd1 = new addform();

            maintoadd1.Enabled = true;

            maintoadd1.Show();

            maintoadd1.Refresh();
        }

        /// <summary>
        /// 変更フォームへの移動
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnChng1_Click(object sender, EventArgs e)
        {
            this.Visible = false;

            changeform maintochng1 = new changeform();

            //変更画面
            maintochng1.Enabled = true;

            maintochng1.Show();

            maintochng1.Refresh();
        }
        
        /// <summary>
        /// 削除フォームへの移動
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnDel1_Click(object sender, EventArgs e)
        {
            this.Visible = false;

            delForm maintodel1 = new delForm();

            //削除画面
            maintodel1.Enabled = true;

            maintodel1.Show();

            maintodel1.Refresh();
        }

        /// <summary>
        /// 閉じる
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        /// <summary>
        /// 各種ボタン：操作不要
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void dGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

    }
}

