﻿namespace kadai3_1
{
    partial class addform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAdd2 = new System.Windows.Forms.Button();
            this.btnCan1 = new System.Windows.Forms.Button();
            this.cmbGen1 = new System.Windows.Forms.ComboBox();
            this.cmbJob1 = new System.Windows.Forms.ComboBox();
            this.lbNo1 = new System.Windows.Forms.Label();
            this.lbGen1 = new System.Windows.Forms.Label();
            this.lbJob1 = new System.Windows.Forms.Label();
            this.lbName1 = new System.Windows.Forms.Label();
            this.tbName = new System.Windows.Forms.TextBox();
            this.lbNoDisp = new System.Windows.Forms.Label();
            this.lbExp = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnAdd2
            // 
            this.btnAdd2.Font = new System.Drawing.Font("メイリオ", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnAdd2.Location = new System.Drawing.Point(158, 250);
            this.btnAdd2.Margin = new System.Windows.Forms.Padding(2);
            this.btnAdd2.Name = "btnAdd2";
            this.btnAdd2.Size = new System.Drawing.Size(116, 70);
            this.btnAdd2.TabIndex = 0;
            this.btnAdd2.TabStop = false;
            this.btnAdd2.Text = "追加する";
            this.btnAdd2.UseVisualStyleBackColor = true;
            this.btnAdd2.Click += new System.EventHandler(this.btnAdd2_Click);
            // 
            // btnCan1
            // 
            this.btnCan1.Font = new System.Drawing.Font("メイリオ", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnCan1.Location = new System.Drawing.Point(313, 250);
            this.btnCan1.Margin = new System.Windows.Forms.Padding(2);
            this.btnCan1.Name = "btnCan1";
            this.btnCan1.Size = new System.Drawing.Size(136, 70);
            this.btnCan1.TabIndex = 1;
            this.btnCan1.TabStop = false;
            this.btnCan1.Text = "キャンセル";
            this.btnCan1.UseVisualStyleBackColor = true;
            this.btnCan1.Click += new System.EventHandler(this.btnCan1_Click);
            // 
            // cmbGen1
            // 
            this.cmbGen1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbGen1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbGen1.Font = new System.Drawing.Font("メイリオ", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.cmbGen1.FormattingEnabled = true;
            this.cmbGen1.Location = new System.Drawing.Point(158, 112);
            this.cmbGen1.Margin = new System.Windows.Forms.Padding(2);
            this.cmbGen1.MaxLength = 10;
            this.cmbGen1.Name = "cmbGen1";
            this.cmbGen1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.cmbGen1.Size = new System.Drawing.Size(293, 39);
            this.cmbGen1.TabIndex = 7;
            this.cmbGen1.TabStop = false;
            this.cmbGen1.SelectedIndexChanged += new System.EventHandler(this.cmbGen1_SelectedIndexChanged);
            // 
            // cmbJob1
            // 
            this.cmbJob1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbJob1.Font = new System.Drawing.Font("メイリオ", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.cmbJob1.FormattingEnabled = true;
            this.cmbJob1.ImeMode = System.Windows.Forms.ImeMode.On;
            this.cmbJob1.Location = new System.Drawing.Point(158, 159);
            this.cmbJob1.Margin = new System.Windows.Forms.Padding(2);
            this.cmbJob1.MaxLength = 10;
            this.cmbJob1.Name = "cmbJob1";
            this.cmbJob1.Size = new System.Drawing.Size(293, 39);
            this.cmbJob1.TabIndex = 8;
            this.cmbJob1.TabStop = false;
            this.cmbJob1.SelectedIndexChanged += new System.EventHandler(this.cmbJob1_SelectedIndexChanged);
            // 
            // lbNo1
            // 
            this.lbNo1.AutoSize = true;
            this.lbNo1.Font = new System.Drawing.Font("メイリオ", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lbNo1.Location = new System.Drawing.Point(81, 74);
            this.lbNo1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbNo1.Name = "lbNo1";
            this.lbNo1.Size = new System.Drawing.Size(52, 33);
            this.lbNo1.TabIndex = 10;
            this.lbNo1.Text = "No.";
            this.lbNo1.Click += new System.EventHandler(this.lbNo1_Click);
            // 
            // lbGen1
            // 
            this.lbGen1.AutoSize = true;
            this.lbGen1.Font = new System.Drawing.Font("メイリオ", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lbGen1.Location = new System.Drawing.Point(81, 118);
            this.lbGen1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbGen1.Name = "lbGen1";
            this.lbGen1.Size = new System.Drawing.Size(59, 33);
            this.lbGen1.TabIndex = 11;
            this.lbGen1.Text = "性別";
            this.lbGen1.Click += new System.EventHandler(this.lbGen1_Click);
            // 
            // lbJob1
            // 
            this.lbJob1.AutoSize = true;
            this.lbJob1.Font = new System.Drawing.Font("メイリオ", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lbJob1.Location = new System.Drawing.Point(81, 166);
            this.lbJob1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbJob1.Name = "lbJob1";
            this.lbJob1.Size = new System.Drawing.Size(59, 33);
            this.lbJob1.TabIndex = 12;
            this.lbJob1.Text = "職業";
            this.lbJob1.Click += new System.EventHandler(this.lbJob1_Click);
            // 
            // lbName1
            // 
            this.lbName1.AutoSize = true;
            this.lbName1.Font = new System.Drawing.Font("メイリオ", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lbName1.Location = new System.Drawing.Point(81, 212);
            this.lbName1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbName1.Name = "lbName1";
            this.lbName1.Size = new System.Drawing.Size(59, 33);
            this.lbName1.TabIndex = 13;
            this.lbName1.Text = "氏名";
            this.lbName1.Click += new System.EventHandler(this.lbName1_Click);
            // 
            // tbName
            // 
            this.tbName.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.tbName.Font = new System.Drawing.Font("メイリオ", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.tbName.Location = new System.Drawing.Point(158, 203);
            this.tbName.MaxLength = 20;
            this.tbName.Name = "tbName";
            this.tbName.Size = new System.Drawing.Size(293, 39);
            this.tbName.TabIndex = 14;
            this.tbName.TabStop = false;
            this.tbName.TextChanged += new System.EventHandler(this.tbName_TextChanged);
            // 
            // lbNoDisp
            // 
            this.lbNoDisp.AutoSize = true;
            this.lbNoDisp.Font = new System.Drawing.Font("メイリオ", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lbNoDisp.Location = new System.Drawing.Point(158, 74);
            this.lbNoDisp.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbNoDisp.Name = "lbNoDisp";
            this.lbNoDisp.Size = new System.Drawing.Size(306, 33);
            this.lbNoDisp.TabIndex = 16;
            this.lbNoDisp.Text = "登録番号                             ";
            this.lbNoDisp.Click += new System.EventHandler(this.lbNoDisp_Click);
            // 
            // lbExp
            // 
            this.lbExp.AutoSize = true;
            this.lbExp.Font = new System.Drawing.Font("メイリオ", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lbExp.Location = new System.Drawing.Point(85, 36);
            this.lbExp.Name = "lbExp";
            this.lbExp.Size = new System.Drawing.Size(169, 33);
            this.lbExp.TabIndex = 17;
            this.lbExp.Text = "上から順に入力";
            // 
            // addform
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(510, 360);
            this.Controls.Add(this.lbExp);
            this.Controls.Add(this.lbNoDisp);
            this.Controls.Add(this.tbName);
            this.Controls.Add(this.lbName1);
            this.Controls.Add(this.lbJob1);
            this.Controls.Add(this.lbGen1);
            this.Controls.Add(this.lbNo1);
            this.Controls.Add(this.cmbJob1);
            this.Controls.Add(this.cmbGen1);
            this.Controls.Add(this.btnCan1);
            this.Controls.Add(this.btnAdd2);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "addform";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "AddForm";
            this.Load += new System.EventHandler(this.addform_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAdd2;
        private System.Windows.Forms.Button btnCan1;
        private System.Windows.Forms.ComboBox cmbGen1;
        private System.Windows.Forms.ComboBox cmbJob1;
        private System.Windows.Forms.Label lbNo1;
        private System.Windows.Forms.Label lbGen1;
        private System.Windows.Forms.Label lbJob1;
        private System.Windows.Forms.Label lbName1;
        private System.Windows.Forms.TextBox tbName;
        private System.Windows.Forms.Label lbNoDisp;
        private System.Windows.Forms.Label lbExp;
    }
}