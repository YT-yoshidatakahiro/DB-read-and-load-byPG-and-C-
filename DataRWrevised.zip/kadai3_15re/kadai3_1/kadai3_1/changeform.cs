﻿using System;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace kadai3_1
{
    public partial class changeform : Form
    {
        public changeform()
        {
            InitializeComponent();

            tbNo2.KeyPress += new KeyPressEventHandler(tbNo2_Keypress);


            tbName2.Click += new EventHandler(tbName2_Click);

            tbName2.KeyPress += new KeyPressEventHandler(tbName2_Keypress);

            ControlBox = false;
        }

        pqsldb chgtomain1 = new pqsldb();

        /// <summary>
        ///性別・職業リスト一覧の読み込み用データの設定
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void changeform_Load_1(object sender, EventArgs e)
        {

            //性別リスト表示
            cmbGen2.Enabled = true;

            //maindatatable読込
            chgtomain1.test();

            chgtomain1.test1();

            for (int i = 0; i < chgtomain1.pgconn5.Tables["genderdb"].Rows.Count; i++)
            {

                cmbGen2.Items.Add(chgtomain1.pgconn5.Tables["genderdb"].Rows[i][1]);
            }

            //職業リスト表示
            cmbJob2.Enabled = true;

            chgtomain1.test2();

            for (int i = 0; i < chgtomain1.pgconn5.Tables["jobdb"].Rows.Count; i++)
            {

                cmbJob2.Items.Add(chgtomain1.pgconn5.Tables["jobdb"].Rows[i][1]);
            }

            cmbJob2.Enabled = false;
            tbName2.Enabled = false;
            btnChng2.Enabled = false;
        }

        /// <summary>
        /// 入力規則
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        // 登録番号の入力制限：数字のみ
        private void tbNo2_Keypress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if ((e.KeyChar < '0' || '9' < e.KeyChar) && e.KeyChar != '\b')
            {
                e.Handled = true;
            }
        }

        /// <summary>
        /// 入力規則
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tbName2_Keypress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar)&& (e.KeyChar != '\b')&&(e.KeyChar !='　'))
            {
                e.Handled = true;
            }

        }

        /// <summary>
        /// 番号リストに適した番号があるか
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tbNo2_TextChanged(object sender, EventArgs e)
        {
            //番号の有無確認
            chgtomain1.test();
            if (tbNo2.Text.Length>=1)
            {
                cmbGen2.Enabled = true;
            }
            else if(tbNo2.Text.Length == 0)
            {
                cmbGen2.Enabled = false;
                cmbJob2.Enabled = false;
                tbName2.Enabled = false;
                btnChng2.Enabled = false;
            }
        }

        /// <summary>
        /// クリック動作
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cmbGen2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbGen2.Text != "")
            {
                cmbJob2.Enabled = true;
            }
            else
            {
                cmbJob2.Enabled = false;
                tbName2.Enabled = false;
                btnChng2.Enabled = false;
            }
        }

        /// <summary>
        /// クリック動作
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cmbJob2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbJob2.Text != "")
            {
                tbName2.Enabled = true;
            }
            else
            {
                tbName2.Enabled = false;
                btnChng2.Enabled = false;
            }
        }

        /// <summary>
        /// 入力規則
        /// </summary>
        /// <param name="str"></param>
        /// <param name="ch"></param>
        /// <returns></returns>
        private static int CountChar(string str, string ch)
        {
            return str.Length - str.Replace(ch.ToString(), "").Length;
        }

        /// <summary>
        /// 入力規則
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tbName2_TextChanged(object sender, EventArgs e)
        {
            tbName2.SelectionStart = tbName2.Text.Length;

            Regex onlyhira1 = new Regex(@"[a-z]");
            Regex onlyhira2 = new Regex(@"[A-Z]");
            Regex onlyhira3 = new Regex(@"[ａ-ｚ]");
            Regex onlyhira4 = new Regex(@"[Ａ-Ｚ]");

            tbName2.Text = onlyhira1.Replace(tbName2.Text, "");
            tbName2.Text = onlyhira2.Replace(tbName2.Text, "");
            tbName2.Text = onlyhira3.Replace(tbName2.Text, "");
            tbName2.Text = onlyhira4.Replace(tbName2.Text, "");

            if (tbName2.Text.StartsWith("　"))
            {
                tbName2.Text = "";
                MessageBox.Show("氏名は全角入力 \n " +
                                    "氏名の間には全角スペース \n " +
                                        "氏名の前後に全角スペース入力不可");

                btnChng2.Enabled = false;
            }
            else if (CountChar(tbName2.Text, "　") >= 2)
            {
                MessageBox.Show("氏名は全角入力 \n " +
                                    "氏名の間には全角スペース \n " +
                                        "氏名の前後に全角スペース入力不可");
                tbName2.Text = tbName2.Text.Remove(tbName2.Text.Length - 1, 1);

                btnChng2.Enabled = false;
            }
            else if (Regex.IsMatch(tbName2.Text, "[　]+."))
            {
                btnChng2.Enabled = true;
            }
            else
            {
                btnChng2.Enabled = false;
            }
        }

        /// <summary>
        /// クリック動作
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tbName2_Click(object sender, EventArgs e)
        {
           if (!tbName2.Text.Equals(""))
           {
               btnChng2.Enabled = true;
           }else
           {
               btnChng2.Enabled = false;
           
           }
        }

        /// <summary>
        /// 変更ボタンの設定
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// 
        public string chngnum;

        private void btnChng2_Click(object sender, EventArgs e)
        {
            chgtomain1.test();

            for (int i = 0; i < chgtomain1.pgconn5.Tables["maindb"].Rows.Count; i++)
            {
                if (!(tbNo2.Text == chgtomain1.pgconn5.Tables["maindb"].Rows[i][0].ToString()))
                { 
                    MessageBox.Show("記録がありません");
                }else if (tbNo2.Text == chgtomain1.pgconn5.Tables["maindb"].Rows[i][0].ToString())
                {
                    chngnum = i.ToString();

                    chgtomain1.dGV[0, i].Value = tbNo2.Text;

                    chgtomain1.dGV[1, i].Value = cmbGen2.Text;

                    chgtomain1.dGV[2, i].Value = cmbJob2.Text;

                    chgtomain1.dGV[3, i].Value = tbName2.Text;

                    chgtomain1.test6();

                    tbName2.Text = "";

                    this.Refresh();

                    this.Visible = false;

                    chgtomain1.Show();

                    break;
                }
            }
        }

        /// <summary>
        /// キャンセルボタン：メインフォームへ移動
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCan2_Click(object sender, EventArgs e)
        {
            pqsldb chgtomain1 = new pqsldb();

            this.Visible = false;

            chgtomain1.Show();

            chgtomain1.Refresh();
        }


    }
}
