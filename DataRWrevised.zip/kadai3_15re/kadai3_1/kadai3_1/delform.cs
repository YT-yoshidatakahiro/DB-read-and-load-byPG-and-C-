﻿using System;
using System.Windows.Forms;

namespace kadai3_1
{
    public partial class delForm : Form
    {
        public delForm()
        {
            InitializeComponent();

            tbDelNo.KeyPress += new KeyPressEventHandler(tbDelNo_KeyPress);

            ControlBox = false;
        }

        pqsldb deltomain1 = new pqsldb();

        /// <summary>
        /// 各種ボタン：設定不要
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void delForm_Load(object sender, EventArgs e)
        {
            btDelR.Enabled = false;
        }

        /// <summary>
        /// 登録番号の入力制限：数字のみ
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tbDelNo_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if ((e.KeyChar < '0' || '9' < e.KeyChar) && e.KeyChar != '\b')
            {
                e.Handled = true;
            }
        }

        /// <summary>
        /// 削除するボタンの開閉
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tbDelNo_TextChanged(object sender, EventArgs e)
        {
            if (tbDelNo.Text.Length == 0)
            {
                btDelR.Enabled = false;
            }
            else if (tbDelNo.Text.Length >= 1)
            {
                btDelR.Enabled = true;
            }
        }

        /// <summary>
        ///削除ボタン設定
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public string delnum;

        private void btDelR_Click(object sender, EventArgs e)
        {
            deltomain1.test();

            for (int i = 0;i< deltomain1.pgconn5.Tables["maindb"].Rows.Count; i++)
            {
                if (!(tbDelNo.Text == deltomain1.pgconn5.Tables["maindb"].Rows[i][0].ToString()))
                {
                    MessageBox.Show("記録がありません");
                }
                else if (tbDelNo.Text == deltomain1.pgconn5.Tables["maindb"].Rows[i][0].ToString())
                {
                    delnum = i.ToString();

                    deltomain1.test5();

                    deltomain1.dGV.Rows[i].Selected = true;

                    foreach (DataGridViewRow delrow in deltomain1.dGV.SelectedRows)
                    {
                        deltomain1.dGV.Rows.Remove(delrow);
                    }

                    tbDelNo.Text = "";

                    this.Refresh();

                    this.Visible = true;

                    deltomain1.Show();
                }
            }
        }

        /// <summary>
        //キャンセルボタン
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btDelToMain_Click(object sender, EventArgs e)
        {
            this.Refresh();

            this.Visible = false;

            deltomain1.ShowDialog();

            this.Close();
        }

        /// <summary>
        /// 不要
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void lbNo5_Click(object sender, EventArgs e)
        {
        }
    }
}
