﻿using System;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace kadai3_1
{
    public partial class addform : Form
    {
        public addform()
        {
            InitializeComponent();

            tbName.Click += new EventHandler(tbName_Click);

            tbName.KeyPress += new KeyPressEventHandler(tbName_Keypress);

            ControlBox = false;
        }

        //メイン画面とのリンク
        pqsldb addtomain1 = new pqsldb();

        /// <summary>
        /// 追加フォーム起動：ナンバリング・性別・職業リスト一覧をコンボボックスに設定
        /// /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void addform_Load(object sender, EventArgs e)
        {
            //性別リスト表示
            cmbGen1.Enabled = true;

            //maindatatable読込
            addtomain1.test();

            addtomain1.test1();

            for (int i = 0; i < addtomain1.pgconn5.Tables["genderdb"].Rows.Count; i++){

                cmbGen1.Items.Add(addtomain1.pgconn5.Tables["genderdb"].Rows[i][1]);
            }

            //職業リスト表示
            cmbJob1.Enabled = true;

            addtomain1.test2();

            for (int i = 0; i < addtomain1.pgconn5.Tables["jobdb"].Rows.Count; i++)
            {

                cmbJob1.Items.Add(addtomain1.pgconn5.Tables["jobdb"].Rows[i][1]);
            }

            cmbJob1.Enabled = false;
            tbName.Enabled = false;
            btnAdd2.Enabled = false;

            //登録番号の表示
            addtomain1.test3();
 
            if (addtomain1.pgconn5.Tables["maindb"].Rows.Count >= 1)
            {
                lbNoDisp.Text = addtomain1.addNo;
            }
            else
            {
                lbNoDisp.Text = "1";
            }
        }

        /// <summary>
        /// 性別リスト入力時
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cmbGen1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbGen1.Text != "")
            {
                cmbJob1.Enabled = true;
            }
            else 
            {
                cmbJob1.Enabled = false;
                tbName.Enabled = false;
                btnAdd2.Enabled = false;
            }
        }

        /// <summary>
        /// 職業リスト選択時
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cmbJob1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbJob1.Text != "")
            {
                tbName.Enabled = true;
            }
            else 
            {
                tbName.Enabled = false;
                btnAdd2.Enabled = false;
            }
        }

        /// <summary>
        /// 氏名入力規則
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tbName_Keypress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && (e.KeyChar != '\b') && (e.KeyChar != '　'))
            {
                e.Handled = true;
            }
        }

        /// <summary>
        /// 氏名入力規則
        /// </summary>
        /// <param name="str"></param>
        /// <param name="ch"></param>
        /// <returns></returns>
        private static int CountChar(string str, string ch)
        {
            return str.Length - str.Replace(ch.ToString(), "").Length;
        }

        /// <summary>
        /// 氏名入力規則
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tbName_TextChanged(object sender, EventArgs e)
        {
            tbName.SelectionStart = tbName.Text.Length;

            //半角英数字不可：全角日本語で「○○　▲▲」間は全角スペースのみ
            Regex onlyhira1 = new Regex(@"[a-z]");
            Regex onlyhira2 = new Regex(@"[A-Z]");
            Regex onlyhira3 = new Regex(@"[ａ-ｚ]");
            Regex onlyhira4 = new Regex(@"[Ａ-Ｚ]");

            tbName.Text = onlyhira1.Replace(tbName.Text, "");
            tbName.Text = onlyhira2.Replace(tbName.Text, "");
            tbName.Text = onlyhira3.Replace(tbName.Text, "");
            tbName.Text = onlyhira4.Replace(tbName.Text, "");

            if (tbName.Text.StartsWith("　"))
            {
                tbName.Text = "";
                MessageBox.Show("氏名は全角入力 \n " +
                                    "氏名の間には全角スペース \n " +
                                        "氏名の前後に全角スペース入力不可");

                btnAdd2.Enabled = false;
            }
            else if (CountChar(tbName.Text, "　") >= 2)
            {
                MessageBox.Show("氏名は全角入力 \n " +
                                    "氏名の間には全角スペース \n " +
                                        "氏名の前後に全角スペース入力不可");

                tbName.Text = tbName.Text.Remove(tbName.Text.Length - 1, 1);

                btnAdd2.Enabled = false;
            }
            else if (Regex.IsMatch(tbName.Text, "[　]+."))
            {
                btnAdd2.Enabled = true;
            }
            else
            {
                btnAdd2.Enabled = false;
            }
        }

        /// <summary>
        /// 氏名入力時のクリック
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tbName_Click(object sender, EventArgs e)
        {
            if (!tbName.Text.Equals(""))
            {
                btnAdd2.Enabled = true;
            }
            else
            {
                btnAdd2.Enabled = false;
            }
        }

        /// <summary>
        /// 追加ボタン：メインデータリストへ一行追加
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAdd2_Click(object sender, EventArgs e)
        {
            addtomain1.test();
            //入力分を直接グリッドビューへ
            addtomain1.dGV.Rows.Add();
            
            addtomain1.dGV[0,addtomain1.pgconn5.Tables["maindb"].Rows.Count - 1].Value = Convert.ToInt32(lbNoDisp.Text);

            addtomain1.dGV[1,addtomain1.pgconn5.Tables["maindb"].Rows.Count - 1].Value = cmbGen1.Text;

            addtomain1.dGV[2,addtomain1.pgconn5.Tables["maindb"].Rows.Count - 1].Value = cmbJob1.Text;
            
            addtomain1.dGV[3,addtomain1.pgconn5.Tables["maindb"].Rows.Count - 1].Value = tbName.Text;

            addtomain1.dGV.Rows[addtomain1.pgconn5.Tables["maindb"].Rows.Count - 1].HeaderCell.Value = (addtomain1.dGV.Rows.Count - 1).ToString();

            addtomain1.test4();

            this.Refresh();

            this.Visible = false;

            tbName.Text = "";

            addtomain1.dGV.Refresh();
            
            addtomain1.Show();
        }

        /// <summary>
        /// キャンセル：フォームを閉じる
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCan1_Click(object sender, EventArgs e)
        {
            pqsldb addtomain1 = new pqsldb();

            addtomain1.dGV.Refresh();

            addtomain1.dGV.Update();

            this.Refresh();

            this.Visible = false;

            addtomain1.Show();
        }

        /// <summary>
        /// 各種ラベル:設定なし
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void lbNoDisp_Click(object sender, EventArgs e)
        {
        }
        private void lbNo1_Click(object sender, EventArgs e)
        {
        }
        private void lbGen1_Click(object sender, EventArgs e)
        {
        }
        private void lbJob1_Click(object sender, EventArgs e)
        {
        }
        private void lbName1_Click(object sender, EventArgs e)
        {
        }
        private void genderBindingSource_CurrentChanged(object sender, EventArgs e)
        {
        }
    }
}
