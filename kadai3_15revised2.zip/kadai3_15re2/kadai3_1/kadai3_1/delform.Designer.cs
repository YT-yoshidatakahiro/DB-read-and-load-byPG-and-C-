﻿namespace kadai3_1
{
    partial class delForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbDelNo = new System.Windows.Forms.TextBox();
            this.lbNo4 = new System.Windows.Forms.Label();
            this.lbNo5 = new System.Windows.Forms.Label();
            this.btDelR = new System.Windows.Forms.Button();
            this.btDelToMain = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // tbDelNo
            // 
            this.tbDelNo.Font = new System.Drawing.Font("メイリオ", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.tbDelNo.Location = new System.Drawing.Point(61, 49);
            this.tbDelNo.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbDelNo.Name = "tbDelNo";
            this.tbDelNo.Size = new System.Drawing.Size(103, 39);
            this.tbDelNo.TabIndex = 0;
            this.tbDelNo.TabStop = false;
            this.tbDelNo.TextChanged += new System.EventHandler(this.tbDelNo_TextChanged);
            // 
            // lbNo4
            // 
            this.lbNo4.AutoSize = true;
            this.lbNo4.Font = new System.Drawing.Font("メイリオ", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lbNo4.Location = new System.Drawing.Point(9, 54);
            this.lbNo4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbNo4.Name = "lbNo4";
            this.lbNo4.Size = new System.Drawing.Size(52, 33);
            this.lbNo4.TabIndex = 1;
            this.lbNo4.Text = "No.";
            // 
            // lbNo5
            // 
            this.lbNo5.AutoSize = true;
            this.lbNo5.Font = new System.Drawing.Font("メイリオ", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lbNo5.Location = new System.Drawing.Point(9, 14);
            this.lbNo5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbNo5.Name = "lbNo5";
            this.lbNo5.Size = new System.Drawing.Size(213, 33);
            this.lbNo5.TabIndex = 2;
            this.lbNo5.Text = "削除する番号を入力";
            this.lbNo5.Click += new System.EventHandler(this.lbNo5_Click);
            // 
            // btDelR
            // 
            this.btDelR.Font = new System.Drawing.Font("メイリオ", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btDelR.Location = new System.Drawing.Point(209, 46);
            this.btDelR.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btDelR.Name = "btDelR";
            this.btDelR.Size = new System.Drawing.Size(117, 40);
            this.btDelR.TabIndex = 3;
            this.btDelR.TabStop = false;
            this.btDelR.Text = "削除する";
            this.btDelR.UseVisualStyleBackColor = true;
            this.btDelR.Click += new System.EventHandler(this.btDelR_Click);
            // 
            // btDelToMain
            // 
            this.btDelToMain.Font = new System.Drawing.Font("メイリオ", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btDelToMain.Location = new System.Drawing.Point(162, 91);
            this.btDelToMain.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btDelToMain.Name = "btDelToMain";
            this.btDelToMain.Size = new System.Drawing.Size(164, 39);
            this.btDelToMain.TabIndex = 4;
            this.btDelToMain.TabStop = false;
            this.btDelToMain.Text = "キャンセル";
            this.btDelToMain.UseVisualStyleBackColor = true;
            this.btDelToMain.Click += new System.EventHandler(this.btDelToMain_Click);
            // 
            // delForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(374, 184);
            this.Controls.Add(this.btDelToMain);
            this.Controls.Add(this.btDelR);
            this.Controls.Add(this.lbNo5);
            this.Controls.Add(this.lbNo4);
            this.Controls.Add(this.tbDelNo);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "delForm";
            this.Text = "delform";
            this.Load += new System.EventHandler(this.delForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbDelNo;
        private System.Windows.Forms.Label lbNo4;
        private System.Windows.Forms.Label lbNo5;
        private System.Windows.Forms.Button btDelR;
        private System.Windows.Forms.Button btDelToMain;
    }
}