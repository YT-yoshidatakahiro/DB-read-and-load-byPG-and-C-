﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.Odbc;
using System.Data.Common;

namespace kadai3_1
{
    public partial class pqsldb : Form
    {
        public string pgsqlstr1 =
                                     "Dsn=PostgreSQL35WKaiin;" +
                                     "Server =localhost;" +
                                     "Port = 5432;" +
                                     "User id=postgres;" +
                                     "Pwd=postgres;" +
                                     "DataBase=kaiin";

        //Dataset構成要素
        public string[] listname ={"id", "gender", "job", "name"};
        
        public string[] tablename = { "kaiin", "gender", "job" };

        public string[] sqlename ={"select * from kaiin order by id asc", 
                                    "select * from gender" ,
                                    "select * from job" };

        //格納用データセット
        public DataSet pgconn5 = new DataSet();

        //データセットへの格納用テーブル
        DataTable pgconn4 = new DataTable();

        //DBとのコネクション
        public OdbcConnection pgconn1 = new OdbcConnection();

        public OdbcCommand pgconn2 = new OdbcCommand();

        public OdbcDataAdapter pgconn3 = new OdbcDataAdapter();
        
        //全テーブルの格納実行
        public void datsetDB()
        {
            if (pgconn5.Tables[tablename[0]] ==null)
            {
                //一度dataset内のテーブル削除
                for (int i = 0; i < tablename.Length; i++)
                {
                    pgconn4 = new DataTable();

                    pgconn4.TableName = tablename[i];

                    pgconn5.Tables.Add(pgconn4);

                    pgconn1 = new OdbcConnection();

                    pgconn2 = new OdbcCommand();

                    pgconn3 = new OdbcDataAdapter();

                    pgconn1.ConnectionString = pgsqlstr1;

                    pgconn2.CommandText = sqlename[i];

                    pgconn2.Connection = pgconn1;

                    pgconn3.SelectCommand = pgconn2;

                    pgconn3.Fill(pgconn5.Tables[tablename[i]]);

                    pgconn3.Update(pgconn5.Tables[tablename[0]]);
                }
            }
            else
            {
                pgconn3.Update(pgconn5.Tables[tablename[0]]);
            }
        }

        public void test1()
        {
            pqsldb pqmain = new pqsldb();
            pqmain.datsetDB();
            //dGV.RowCount = pqmain1.pgconn5.Tables[tablename[0]].Rows.Count + 1;

            for (int i = 0; i < pqmain.pgconn5.Tables[tablename[0]].Rows.Count; i++)
            {
                dGV.Rows.Add();

                for (int j = 0; j < listname.Length; j++)
                {
                    var maindat1 = pqmain.pgconn5.Tables[tablename[0]].Rows[i][j];

                    dGV.Rows[i].Cells[j].Value = maindat1;
                }

                //インデックス
                dGV.Rows[i].HeaderCell.Value = (i).ToString();
            }
        }
        //SQL利用分

        //追加画面でのSQL
        public string sqlac1111 = @"select max(id) from kaiin";

        public string sqlac11111 = @"insert into kaiin(id, gender,job,name) values(?,?,?,?)";

        public string sqlac111111 = @"delete from kaiin where id = ?";

        //変更画面でのSQL
        public string sqlac1111111 = @"update kaiin set gender =?, job = ?, name =? where id =? ";

        /// <summary>
        /// 追加画面での番号
        /// </summary>
        public string addNo;
        public void test3()
        {
            pgconn1 = new OdbcConnection();

            pgconn2 = new OdbcCommand();

            pgconn3 = new OdbcDataAdapter();

            //番号の格納
            pgconn1.ConnectionString = pgsqlstr1;

            pgconn2.CommandText = sqlac1111;

            pgconn2.Connection = pgconn1;

            pgconn3.SelectCommand = pgconn2;

             //追加画面番号

            pgconn1.Open();

            addNo = Convert.ToString(Convert.ToInt32(pgconn2.ExecuteScalar()) + 1);

            pgconn1.Close();
        }

        /// <summary>
        /// 追加画面での追加実行
        /// </summary>
        public void test4()
        {
            //グリッドビューのデータをSQLへ
            pgconn1 = new OdbcConnection();

            pgconn2 = new OdbcCommand();

            pgconn3 = new OdbcDataAdapter();

            //番号の格納
            pgconn1.ConnectionString = pgsqlstr1;

            pgconn2.CommandText = sqlac11111;

            pgconn2.Connection = pgconn1;

            pgconn3.SelectCommand = pgconn2;

            for (int i =0; i< listname.Length; i++)
            {
                pgconn2.Parameters.Add(new OdbcParameter("@"+listname[i], dGV[i, 0].Value));
            }

            pgconn1.Open();

            pgconn2.ExecuteNonQuery();

            pgconn1.Close();
        }

        /// <summary>
        ///削除画面での登録削除 
        /// </summary>
        public void test5()
        {
            delForm maintodel1 = new delForm();

            //入力番号の削除

            //グリッドビューのデータをSQLへ
            pgconn1 = new OdbcConnection();

            pgconn2 = new OdbcCommand();

            pgconn3 = new OdbcDataAdapter();

            //番号の格納
            pgconn1.ConnectionString = pgsqlstr1;

            pgconn2.CommandText = sqlac111111;

            pgconn2.Connection = pgconn1;

            pgconn3.SelectCommand = pgconn2;

        }

        /// <summary>
        /// 変更画面での変更登録
        /// </summary>
        public void test6()
        {
            changeform maintochng1 = new changeform();

            pgconn1 = new OdbcConnection();

            pgconn2 = new OdbcCommand();

            pgconn3 = new OdbcDataAdapter();

            //番号の格納
            pgconn1.ConnectionString = pgsqlstr1;

            pgconn2.CommandText = sqlac1111111;

            pgconn2.Connection = pgconn1;

            pgconn3.SelectCommand = pgconn2;
        }

        /// <summary>
        /// iniファイルからＤＢパスへのアクセス
        /// </summary>
        public pqsldb()
        {
            InitializeComponent();

            dGV.AllowUserToAddRows = true;

            ControlBox = false;
        }

        /// <summary>
        ///postgresODBC経由での接続設定:データの自動読み込み
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pqsldb_Load(object sender, EventArgs e)
        {
            pqsldb pqmain = new pqsldb();
            pqmain.datsetDB();
            //dGV.RowCount = pqmain1.pgconn5.Tables[tablename[0]].Rows.Count + 1;

            for (int i = 0; i < pqmain.pgconn5.Tables[tablename[0]].Rows.Count; i++)
            {
                dGV.Rows.Add();

                for (int j = 0; j < listname.Length; j++)
                {
                    var maindat1 = pqmain.pgconn5.Tables[tablename[0]].Rows[i][j];

                    dGV.Rows[i].Cells[j].Value = maindat1;
                }

                //インデックス
                dGV.Rows[i].HeaderCell.Value = (i).ToString();
            }
        }

        /// <summary>
        /// 追加フォームへ移動
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAdd1_Click(object sender, EventArgs e)
        {
            this.Visible = false;

            //追加画面
            addform maintoadd1 = new addform();

            maintoadd1.Enabled = true;

            maintoadd1.Show();

            maintoadd1.Refresh();
        }

        /// <summary>
        /// 変更フォームへの移動
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnChng1_Click(object sender, EventArgs e)
        {
            this.Visible = false;

            changeform maintochng1 = new changeform();

            //変更画面
            maintochng1.Enabled = true;

            maintochng1.Show();

            maintochng1.Refresh();
        }
        
        /// <summary>
        /// 削除フォームへの移動
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnDel1_Click(object sender, EventArgs e)
        {
            this.Visible = false;

            delForm maintodel1 = new delForm();

            //削除画面
            maintodel1.Enabled = true;

            maintodel1.Show();

            maintodel1.Refresh();
        }

        /// <summary>
        /// 閉じる
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        /// <summary>
        /// 各種ボタン：操作不要
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void dGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

    }
}

