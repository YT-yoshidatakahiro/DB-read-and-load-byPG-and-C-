﻿using System;

public class gridtable1
{
	public gridtable1()
	{

	}
}
