﻿using System;
using System.Data.Odbc;
using System.Windows.Forms;

namespace kadai3_1
{
    public partial class delForm : Form
    {
        public delForm()
        {
            InitializeComponent();

            tbDelNo.KeyPress += new KeyPressEventHandler(tbDelNo_KeyPress);

            ControlBox = false;
        }

        pqsldb deltomain1 = new pqsldb();

        /// <summary>
        /// 各種ボタン：設定不要
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void delForm_Load(object sender, EventArgs e)
        {
            btDelR.Enabled = false;
        }

        /// <summary>
        /// 登録番号の入力制限：数字のみ
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tbDelNo_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if ((e.KeyChar < '0' || '9' < e.KeyChar) && e.KeyChar != '\b')
            {
                e.Handled = true;
            }
        }

        /// <summary>
        /// 削除するボタンの開閉
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tbDelNo_TextChanged(object sender, EventArgs e)
        {
            if (tbDelNo.Text.Length == 0)
            {
                btDelR.Enabled = false;
            }
            else if (tbDelNo.Text.Length >= 1)
            {
                btDelR.Enabled = true;
            }
        }

        /// <summary>
        ///削除ボタン設定
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btDelR_Click(object sender, EventArgs e)
        {
            deltomain1.datsetDB();

            deltomain1.test5();

            for (int i = 0; i < deltomain1.pgconn5.Tables[deltomain1.tablename[0]].Rows.Count; i++)
            {
                if (deltomain1.pgconn5.Tables[deltomain1.tablename[0]].Rows[i][0].ToString().Equals(tbDelNo.Text))
                {
                    deltomain1.pgconn2.Parameters.Add(
                        new OdbcParameter("@" + deltomain1.listname[0], tbDelNo.Text));

                    deltomain1.pgconn1.Open();

                    deltomain1.pgconn2.ExecuteNonQuery();

                    deltomain1.pgconn1.Close();

                    tbDelNo.Text = "";

                    this.Refresh();

                    this.Visible = false;

                    deltomain1.Show();

                    break;
                }
            }
        }

        /// <summary>
        //キャンセルボタン
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btDelToMain_Click(object sender, EventArgs e)
        {
            this.Refresh();

            this.Visible = false;

            deltomain1.ShowDialog();

            this.Close();
        }

        /// <summary>
        /// 不要
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void lbNo5_Click(object sender, EventArgs e)
        {
        }
    }
}
