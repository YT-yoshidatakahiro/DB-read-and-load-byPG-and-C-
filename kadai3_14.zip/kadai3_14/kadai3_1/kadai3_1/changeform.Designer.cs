﻿namespace kadai3_1
{
    partial class changeform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnChng2 = new System.Windows.Forms.Button();
            this.btnCan2 = new System.Windows.Forms.Button();
            this.tbNo2 = new System.Windows.Forms.TextBox();
            this.cmbGen2 = new System.Windows.Forms.ComboBox();
            this.cmbJob2 = new System.Windows.Forms.ComboBox();
            this.lbNo2 = new System.Windows.Forms.Label();
            this.lbGen2 = new System.Windows.Forms.Label();
            this.lbJob2 = new System.Windows.Forms.Label();
            this.lbName2 = new System.Windows.Forms.Label();
            this.tbName2 = new System.Windows.Forms.TextBox();
            this.lbExp = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnChng2
            // 
            this.btnChng2.Font = new System.Drawing.Font("メイリオ", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnChng2.Location = new System.Drawing.Point(50, 237);
            this.btnChng2.Margin = new System.Windows.Forms.Padding(2);
            this.btnChng2.Name = "btnChng2";
            this.btnChng2.Size = new System.Drawing.Size(112, 66);
            this.btnChng2.TabIndex = 4;
            this.btnChng2.TabStop = false;
            this.btnChng2.Text = "変更する";
            this.btnChng2.UseVisualStyleBackColor = true;
            this.btnChng2.Click += new System.EventHandler(this.btnChng2_Click);
            // 
            // btnCan2
            // 
            this.btnCan2.Font = new System.Drawing.Font("メイリオ", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnCan2.Location = new System.Drawing.Point(176, 237);
            this.btnCan2.Margin = new System.Windows.Forms.Padding(2);
            this.btnCan2.Name = "btnCan2";
            this.btnCan2.Size = new System.Drawing.Size(142, 66);
            this.btnCan2.TabIndex = 5;
            this.btnCan2.TabStop = false;
            this.btnCan2.Text = "キャンセル";
            this.btnCan2.UseVisualStyleBackColor = true;
            this.btnCan2.Click += new System.EventHandler(this.btnCan2_Click);
            // 
            // tbNo2
            // 
            this.tbNo2.Font = new System.Drawing.Font("メイリオ", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.tbNo2.Location = new System.Drawing.Point(146, 46);
            this.tbNo2.Margin = new System.Windows.Forms.Padding(2);
            this.tbNo2.Name = "tbNo2";
            this.tbNo2.Size = new System.Drawing.Size(174, 39);
            this.tbNo2.TabIndex = 9;
            this.tbNo2.TabStop = false;
            this.tbNo2.TextChanged += new System.EventHandler(this.tbNo2_TextChanged);
            // 
            // cmbGen2
            // 
            this.cmbGen2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbGen2.Font = new System.Drawing.Font("メイリオ", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.cmbGen2.FormattingEnabled = true;
            this.cmbGen2.Location = new System.Drawing.Point(146, 89);
            this.cmbGen2.Margin = new System.Windows.Forms.Padding(2);
            this.cmbGen2.Name = "cmbGen2";
            this.cmbGen2.Size = new System.Drawing.Size(174, 39);
            this.cmbGen2.TabIndex = 10;
            this.cmbGen2.TabStop = false;
            this.cmbGen2.SelectedIndexChanged += new System.EventHandler(this.cmbGen2_SelectedIndexChanged);
            // 
            // cmbJob2
            // 
            this.cmbJob2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbJob2.Font = new System.Drawing.Font("メイリオ", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.cmbJob2.FormattingEnabled = true;
            this.cmbJob2.Location = new System.Drawing.Point(146, 134);
            this.cmbJob2.Margin = new System.Windows.Forms.Padding(2);
            this.cmbJob2.Name = "cmbJob2";
            this.cmbJob2.Size = new System.Drawing.Size(174, 39);
            this.cmbJob2.TabIndex = 11;
            this.cmbJob2.TabStop = false;
            this.cmbJob2.SelectedIndexChanged += new System.EventHandler(this.cmbJob2_SelectedIndexChanged);
            // 
            // lbNo2
            // 
            this.lbNo2.AutoSize = true;
            this.lbNo2.Font = new System.Drawing.Font("メイリオ", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lbNo2.Location = new System.Drawing.Point(51, 51);
            this.lbNo2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbNo2.Name = "lbNo2";
            this.lbNo2.Size = new System.Drawing.Size(52, 33);
            this.lbNo2.TabIndex = 13;
            this.lbNo2.Text = "No.";
            // 
            // lbGen2
            // 
            this.lbGen2.AutoSize = true;
            this.lbGen2.Font = new System.Drawing.Font("メイリオ", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lbGen2.Location = new System.Drawing.Point(51, 95);
            this.lbGen2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbGen2.Name = "lbGen2";
            this.lbGen2.Size = new System.Drawing.Size(59, 33);
            this.lbGen2.TabIndex = 14;
            this.lbGen2.Text = "性別";
            // 
            // lbJob2
            // 
            this.lbJob2.AutoSize = true;
            this.lbJob2.Font = new System.Drawing.Font("メイリオ", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lbJob2.Location = new System.Drawing.Point(51, 140);
            this.lbJob2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbJob2.Name = "lbJob2";
            this.lbJob2.Size = new System.Drawing.Size(59, 33);
            this.lbJob2.TabIndex = 15;
            this.lbJob2.Text = "職業";
            // 
            // lbName2
            // 
            this.lbName2.AutoSize = true;
            this.lbName2.Font = new System.Drawing.Font("メイリオ", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lbName2.Location = new System.Drawing.Point(51, 188);
            this.lbName2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbName2.Name = "lbName2";
            this.lbName2.Size = new System.Drawing.Size(59, 33);
            this.lbName2.TabIndex = 16;
            this.lbName2.Text = "氏名";
            // 
            // tbName2
            // 
            this.tbName2.Font = new System.Drawing.Font("メイリオ", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.tbName2.Location = new System.Drawing.Point(148, 178);
            this.tbName2.Name = "tbName2";
            this.tbName2.Size = new System.Drawing.Size(172, 39);
            this.tbName2.TabIndex = 17;
            this.tbName2.TabStop = false;
            this.tbName2.TextChanged += new System.EventHandler(this.tbName2_TextChanged);
            // 
            // lbExp
            // 
            this.lbExp.AutoSize = true;
            this.lbExp.Font = new System.Drawing.Font("メイリオ", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lbExp.Location = new System.Drawing.Point(34, 9);
            this.lbExp.Name = "lbExp";
            this.lbExp.Size = new System.Drawing.Size(169, 33);
            this.lbExp.TabIndex = 18;
            this.lbExp.Text = "上から順に入力";
            // 
            // changeform
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(355, 360);
            this.Controls.Add(this.lbExp);
            this.Controls.Add(this.tbName2);
            this.Controls.Add(this.lbName2);
            this.Controls.Add(this.lbJob2);
            this.Controls.Add(this.lbGen2);
            this.Controls.Add(this.lbNo2);
            this.Controls.Add(this.cmbJob2);
            this.Controls.Add(this.cmbGen2);
            this.Controls.Add(this.tbNo2);
            this.Controls.Add(this.btnCan2);
            this.Controls.Add(this.btnChng2);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "changeform";
            this.Text = "ChangeForm";
            this.Load += new System.EventHandler(this.changeform_Load_1);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnChng2;
        private System.Windows.Forms.Button btnCan2;
        private System.Windows.Forms.TextBox tbNo2;
        private System.Windows.Forms.ComboBox cmbGen2;
        private System.Windows.Forms.ComboBox cmbJob2;
        private System.Windows.Forms.Label lbNo2;
        private System.Windows.Forms.Label lbGen2;
        private System.Windows.Forms.Label lbJob2;
        private System.Windows.Forms.Label lbName2;
        private System.Windows.Forms.TextBox tbName2;
        private System.Windows.Forms.Label lbExp;
    }
}