﻿namespace kadai3_1
{
    partial class pqsldb
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージド リソースを破棄する場合は true を指定し、その他の場合は false を指定します。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnAdd1 = new System.Windows.Forms.Button();
            this.btnChng1 = new System.Windows.Forms.Button();
            this.btnDel1 = new System.Windows.Forms.Button();
            this.dGV = new System.Windows.Forms.DataGridView();
            this.id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gender = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.job = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kaiinBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.postgresSQL35Wkadai64BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.postgresSQL35Wkadai64 = new kadai3_1.postgresSQL35Wkadai64();
            this.postgresDataSet = new kadai3_1.postgresDataSet();
            this.postgresDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.kaiinTableAdapter = new kadai3_1.postgresSQL35Wkadai64TableAdapters.kaiinTableAdapter();
            this.btnClose = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dGV)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kaiinBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.postgresSQL35Wkadai64BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.postgresSQL35Wkadai64)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.postgresDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.postgresDataSetBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // btnAdd1
            // 
            this.btnAdd1.Font = new System.Drawing.Font("メイリオ", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnAdd1.Location = new System.Drawing.Point(23, 209);
            this.btnAdd1.Margin = new System.Windows.Forms.Padding(2);
            this.btnAdd1.Name = "btnAdd1";
            this.btnAdd1.Size = new System.Drawing.Size(142, 94);
            this.btnAdd1.TabIndex = 0;
            this.btnAdd1.TabStop = false;
            this.btnAdd1.Text = "追加画面";
            this.btnAdd1.UseVisualStyleBackColor = true;
            this.btnAdd1.Click += new System.EventHandler(this.btnAdd1_Click);
            // 
            // btnChng1
            // 
            this.btnChng1.Font = new System.Drawing.Font("メイリオ", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnChng1.Location = new System.Drawing.Point(170, 209);
            this.btnChng1.Margin = new System.Windows.Forms.Padding(2);
            this.btnChng1.Name = "btnChng1";
            this.btnChng1.Size = new System.Drawing.Size(142, 94);
            this.btnChng1.TabIndex = 1;
            this.btnChng1.TabStop = false;
            this.btnChng1.Text = "変更画面";
            this.btnChng1.UseVisualStyleBackColor = true;
            this.btnChng1.Click += new System.EventHandler(this.btnChng1_Click);
            // 
            // btnDel1
            // 
            this.btnDel1.Font = new System.Drawing.Font("メイリオ", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnDel1.Location = new System.Drawing.Point(317, 209);
            this.btnDel1.Margin = new System.Windows.Forms.Padding(2);
            this.btnDel1.Name = "btnDel1";
            this.btnDel1.Size = new System.Drawing.Size(142, 94);
            this.btnDel1.TabIndex = 2;
            this.btnDel1.TabStop = false;
            this.btnDel1.Text = "削除画面";
            this.btnDel1.UseVisualStyleBackColor = true;
            this.btnDel1.Click += new System.EventHandler(this.btnDel1_Click);
            // 
            // dGV
            // 
            this.dGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dGV.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.id,
            this.gender,
            this.job,
            this.name});
            this.dGV.Enabled = false;
            this.dGV.Location = new System.Drawing.Point(23, 9);
            this.dGV.Margin = new System.Windows.Forms.Padding(2);
            this.dGV.Name = "dGV";
            this.dGV.ReadOnly = true;
            this.dGV.RowTemplate.Height = 24;
            this.dGV.ShowCellToolTips = false;
            this.dGV.Size = new System.Drawing.Size(550, 197);
            this.dGV.TabIndex = 3;
            this.dGV.TabStop = false;
            this.dGV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dGV_CellContentClick);
            // 
            // id
            // 
            this.id.HeaderText = "id";
            this.id.Name = "id";
            this.id.ReadOnly = true;
            // 
            // gender
            // 
            this.gender.HeaderText = "gender";
            this.gender.Name = "gender";
            this.gender.ReadOnly = true;
            // 
            // job
            // 
            this.job.HeaderText = "job";
            this.job.Name = "job";
            this.job.ReadOnly = true;
            // 
            // name
            // 
            this.name.HeaderText = "name";
            this.name.Name = "name";
            this.name.ReadOnly = true;
            // 
            // kaiinBindingSource
            // 
            this.kaiinBindingSource.DataMember = "kaiin";
            this.kaiinBindingSource.DataSource = this.postgresSQL35Wkadai64BindingSource;
            // 
            // postgresSQL35Wkadai64BindingSource
            // 
            this.postgresSQL35Wkadai64BindingSource.DataSource = this.postgresSQL35Wkadai64;
            this.postgresSQL35Wkadai64BindingSource.Position = 0;
            // 
            // postgresSQL35Wkadai64
            // 
            this.postgresSQL35Wkadai64.DataSetName = "postgresSQL35Wkadai64";
            this.postgresSQL35Wkadai64.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // postgresDataSet
            // 
            this.postgresDataSet.DataSetName = "postgresDataSet";
            this.postgresDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // postgresDataSetBindingSource
            // 
            this.postgresDataSetBindingSource.DataSource = this.postgresDataSet;
            this.postgresDataSetBindingSource.Position = 0;
            // 
            // kaiinTableAdapter
            // 
            this.kaiinTableAdapter.ClearBeforeFill = true;
            // 
            // btnClose
            // 
            this.btnClose.Font = new System.Drawing.Font("メイリオ", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnClose.Location = new System.Drawing.Point(464, 209);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(109, 94);
            this.btnClose.TabIndex = 4;
            this.btnClose.TabStop = false;
            this.btnClose.Text = "終了";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // pqsldb
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600, 321);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.dGV);
            this.Controls.Add(this.btnDel1);
            this.Controls.Add(this.btnChng1);
            this.Controls.Add(this.btnAdd1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "pqsldb";
            this.Text = "PQSLDB";
            this.Load += new System.EventHandler(this.pqsldb_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dGV)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kaiinBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.postgresSQL35Wkadai64BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.postgresSQL35Wkadai64)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.postgresDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.postgresDataSetBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnAdd1;
        private System.Windows.Forms.Button btnChng1;
        private System.Windows.Forms.Button btnDel1;
        private postgresDataSet postgresDataSet;
        private System.Windows.Forms.BindingSource postgresDataSetBindingSource;
        private System.Windows.Forms.BindingSource postgresSQL35Wkadai64BindingSource;
        private postgresSQL35Wkadai64 postgresSQL35Wkadai64;
        private System.Windows.Forms.BindingSource kaiinBindingSource;
        private postgresSQL35Wkadai64TableAdapters.kaiinTableAdapter kaiinTableAdapter;
        public System.Windows.Forms.DataGridView dGV;
        private System.Windows.Forms.DataGridViewTextBoxColumn id;
        private System.Windows.Forms.DataGridViewTextBoxColumn gender;
        private System.Windows.Forms.DataGridViewTextBoxColumn job;
        private System.Windows.Forms.DataGridViewTextBoxColumn name;
        private System.Windows.Forms.Button btnClose;
    }
}

