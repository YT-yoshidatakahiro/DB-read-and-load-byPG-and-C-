﻿using System;
using System.Windows.Forms;
using System.Data.Odbc;
using System.Data;
using System.Text.RegularExpressions;

namespace kadai3_1
{
    public partial class changeform : Form
    {
        public changeform()
        {
            InitializeComponent();

            tbNo2.KeyPress += new KeyPressEventHandler(tbNo2_Keypress);


            tbName2.Click += new EventHandler(tbName2_Click);

            tbName2.KeyPress += new KeyPressEventHandler(tbName2_Keypress);

            ControlBox = false;
        }

        /// <summary>
        ///性別・職業リスト一覧の読み込み用データの設定
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void changeform_Load_1(object sender, EventArgs e)
        {
            pqsldb chgtomain1 = new pqsldb();

            //性別コンボボックスリスト
            try
            {
                OdbcConnection gendelcmb1 = new OdbcConnection(chgtomain1.pgsqlstr1);

                string delac1 = "select * from gender";

                OdbcCommand gendelcmb2 = new OdbcCommand(delac1, gendelcmb1);

                OdbcDataAdapter gendelcmb3 = new OdbcDataAdapter(gendelcmb2);

                DataTable gendelcmb4 = new DataTable();

                gendelcmb3.Fill(gendelcmb4);

                DataRow gendelcmb5 = gendelcmb4.NewRow();

                gendelcmb5[0] = -1;

                gendelcmb5[1] = "";

                gendelcmb4.Rows.InsertAt(gendelcmb5, 0);

                gendelcmb4.AcceptChanges();

                cmbGen2.DisplayMember = "gender";

                cmbGen2.ValueMember = "id";

                cmbGen2.Enabled = true;

                cmbGen2.DataSource = gendelcmb4;
            }
            catch (Exception)
            {
                tbName2.Enabled = false;
                cmbJob2.Enabled = false;
                cmbGen2.Enabled = false;
                btnChng2.Enabled = false;
            } 

            //職業コンボボックスリスト
            try
            {
                OdbcConnection jobcmb1 = new OdbcConnection(chgtomain1.pgsqlstr1);

                string jobac1 = "select * from job";

                OdbcCommand jobcmb2 = new OdbcCommand(jobac1, jobcmb1);

                OdbcDataAdapter jobcmb3 = new OdbcDataAdapter(jobcmb2);

                DataTable jobcmb4 = new DataTable();

                jobcmb3.Fill(jobcmb4);

                DataRow jobcmb5 = jobcmb4.NewRow();
                jobcmb5[0] = -1;
                jobcmb5[1] = "";

                jobcmb4.Rows.InsertAt(jobcmb5, 0);

                jobcmb4.AcceptChanges();

                cmbJob2.DisplayMember = "job";

                cmbJob2.ValueMember = "id";

                cmbJob2.Enabled = true;

                cmbJob2.DataSource = jobcmb4;
            }
            catch (Exception)
            {
                tbName2.Enabled = false;
                cmbJob2.Enabled = false;
                cmbGen2.Enabled = false;
                btnChng2.Enabled = false;
            }

            tbName2.Enabled = false;
            cmbJob2.Enabled = false;
            cmbGen2.Enabled = false;
            btnChng2.Enabled = false;
        }


        /// <summary>
        /// 入力規則
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        // 登録番号の入力制限：数字のみ
        private void tbNo2_Keypress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if ((e.KeyChar < '0' || '9' < e.KeyChar) && e.KeyChar != '\b')
            {
                e.Handled = true;
            }
        }

        private void tbName2_Keypress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar)&& (e.KeyChar != '\b')&&(e.KeyChar !='　'))
            {
                e.Handled = true;
            }

        }

        /// <summary>
        /// 各種ボタン
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tbNo2_TextChanged(object sender, EventArgs e)
        {
            pqsldb chgtomain1 = new pqsldb();

            //番号の有無確認
             try
             {
                OdbcConnection chconn1 = new OdbcConnection(chgtomain1.pgsqlstr1);
               
                string sqlac0 = @"select count(id) from kaiin where id =? ";
               
                OdbcCommand chconn2 = new OdbcCommand(sqlac0, chconn1);
               
                chconn2.Parameters.Add(new OdbcParameter("@id", Convert.ToInt32(tbNo2.Text)));
               
                Int32 nocount = 0;
               
                chconn1.Open();
            
                 nocount = Convert.ToInt32(chconn2.ExecuteScalar());
            
                 if (nocount >=1)
                 {

                    cmbGen2.Enabled = true;
                }
                else
                 {
                    cmbGen2.Enabled = false;
                    cmbJob2.Enabled = false;
                    tbName2.Enabled = false;
                    btnChng2.Enabled = false;
                }
                chconn1.Close();
            }
            catch (Exception)
             {
                cmbGen2.Enabled = false;
                cmbJob2.Enabled = false;
                tbName2.Enabled = false;
                btnChng2.Enabled = false;
            }
        }
        private void cmbGen2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbGen2.Text != "")
            {
                cmbJob2.Enabled = true;

            }
            else
            {
                cmbJob2.Enabled = false;
                tbName2.Enabled = false;
                btnChng2.Enabled = false;
            }
        }

        private void cmbJob2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbJob2.Text != "")
            {
                tbName2.Enabled = true;
            }
            else
            {
                tbName2.Enabled = false;
                btnChng2.Enabled = false;
            }
        }
        private static int CountChar(string str, string ch)
        {
            return str.Length - str.Replace(ch.ToString(), "").Length;
        }
        private void tbName2_TextChanged(object sender, EventArgs e)
        {
            tbName2.SelectionStart = tbName2.Text.Length;

            Regex onlyhira1 = new Regex(@"[a-z]");
            Regex onlyhira2 = new Regex(@"[A-Z]");
            Regex onlyhira3 = new Regex(@"[ａ-ｚ]");
            Regex onlyhira4 = new Regex(@"[Ａ-Ｚ]");

            tbName2.Text = onlyhira1.Replace(tbName2.Text, "");
            tbName2.Text = onlyhira2.Replace(tbName2.Text, "");
            tbName2.Text = onlyhira3.Replace(tbName2.Text, "");
            tbName2.Text = onlyhira4.Replace(tbName2.Text, "");

            if (tbName2.Text.StartsWith("　"))
            {
                tbName2.Text = "";
                MessageBox.Show("氏名は全角入力 \n " +
                                    "氏名の間には全角スペース \n " +
                                        "氏名の前後に全角スペース入力不可");

                btnChng2.Enabled = false;
            }
            else if (CountChar(tbName2.Text, "　") >= 2)
            {
                MessageBox.Show("氏名は全角入力 \n " +
                                    "氏名の間には全角スペース \n " +
                                        "氏名の前後に全角スペース入力不可");
                tbName2.Text = tbName2.Text.Remove(tbName2.Text.Length - 1, 1);

                btnChng2.Enabled = false;
            }
            else if (Regex.IsMatch(tbName2.Text, "[　]+."))
            {
                btnChng2.Enabled = true;
            }
            else
            {
                btnChng2.Enabled = false;
            }
        }

        private void tbName2_Click(object sender, EventArgs e)
        {
           if (!tbName2.Text.Equals(""))
           {
               btnChng2.Enabled = true;
           }else
           {
               btnChng2.Enabled = false;
           
           }
        }

        /// <summary>
        /// 変更ボタンの設定
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnChng2_Click(object sender, EventArgs e)
        {
            
            pqsldb chgtomain1 = new pqsldb();

            OdbcConnection chconn1 = new OdbcConnection(chgtomain1.pgsqlstr1);

            string sqlac1 = @"update kaiin set gender =?, job = ?, name =? where id =? ";

            OdbcCommand chconn2 = new OdbcCommand(sqlac1, chconn1);

            chconn2.Parameters.Add(new OdbcParameter("@id", Convert.ToInt32(tbNo2.Text)));

                chconn1.Open();

                //登録番号の有無・登録番号がある場合の処理

                chconn2 = new OdbcCommand(sqlac1, chconn1);

                chconn2.Parameters.Add(new OdbcParameter("@gender", cmbGen2.Text));

                chconn2.Parameters.Add(new OdbcParameter("@job", cmbJob2.Text));

                chconn2.Parameters.Add(new OdbcParameter("@name", tbName2.Text));

                chconn2.Parameters.Add(new OdbcParameter("@id", Convert.ToInt32(tbNo2.Text)));

                chconn2.ExecuteNonQuery();

                chconn1.Close();

                chgtomain1.dGV.Refresh();

                chgtomain1.dGV.Update();

                tbName2.Text = "";

                this.Refresh();

                this.Visible = false;

                chgtomain1.Show();

        }
        /// <summary>
        /// キャンセルボタン：メインフォームへ移動
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCan2_Click(object sender, EventArgs e)
        {

            pqsldb chgtomain1 = new pqsldb();

            this.Visible = false;

            chgtomain1.Show();

            chgtomain1.Refresh();
        }


    }
}
