﻿using System;
using System.Windows.Forms;
using System.Data.Odbc;
using System.Data;
using System.Data.SqlClient;

namespace kadai3_1
{
    public partial class delForm : Form
    {

        public delForm()
        {
            InitializeComponent();

            tbDelNo.KeyPress += new KeyPressEventHandler(tbDelNo_KeyPress);

            ControlBox = false;
        }

        /// <summary>
        /// 登録番号の入力制限：数字のみ
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tbDelNo_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if ((e.KeyChar < '0' || '9' < e.KeyChar) && e.KeyChar != '\b')
            {
                e.Handled = true;
            }
        }

        /// <summary>
        /// 各種ボタン：設定不要
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void delForm_Load(object sender, EventArgs e)
        {
            btDelR.Enabled = false;

        }

        private void tbDelNo_TextChanged(object sender, EventArgs e)
        {
            pqsldb deltomain1 = new pqsldb();

            try
            {
                if (tbDelNo.Text.Length >= 1)
                {
                    OdbcConnection delconn1 = new OdbcConnection(deltomain1.pgsqlstr1);

                    string sqlac0 = @"select count(id) from kaiin where id =?";

                    OdbcCommand delconn3 = new OdbcCommand(sqlac0, delconn1);

                    Int32 nocount2 = 0;

                    delconn3.Parameters.Add(new OdbcParameter("@id", Convert.ToInt32(tbDelNo.Text)));

                    delconn1.Open();

                    nocount2 = Convert.ToInt32(delconn3.ExecuteScalar());

                    //登録番号の有無
                    if (nocount2 >= 1)
                    {
                        btDelR.Enabled = true;
                    }
                }
                else
                {
                    btDelR.Enabled = false;
                }
            }
            catch (Exception)
            {
                btDelR.Enabled = false;
            }
        }

        /// <summary>
        ///削除ボタン設定
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btDelR_Click(object sender, EventArgs e)
        {
            //入力番号の削除
            pqsldb deltomain1 = new pqsldb();

            OdbcConnection delconn1 = new OdbcConnection(deltomain1.pgsqlstr1);

            string sqlac1 = @"delete from kaiin where id = ?";

            OdbcCommand delconn3 = new OdbcCommand(sqlac1, delconn1);

            delconn3.Parameters.Add(new OdbcParameter("@id", Convert.ToInt32(tbDelNo.Text)));

            Int32 nocount2;

            delconn1.Open();

            nocount2 = Convert.ToInt32(delconn3.ExecuteScalar());

            OdbcCommand delconn4 = new OdbcCommand(sqlac1, delconn1);

            delconn4.Parameters.Add(new OdbcParameter("@id", Convert.ToInt32(tbDelNo.Text)));

            delconn4.ExecuteNonQuery();

            delconn1.Close();

            deltomain1.dGV.Update();

            deltomain1.dGV.Refresh();

            this.Visible = false;

            deltomain1.Show();
        }


        /// <summary>
        //キャンセルボタン
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btDelToMain_Click(object sender, EventArgs e)
        {
            pqsldb deltomain1 = new pqsldb();

            this.Refresh();

            this.Visible = false;

            deltomain1.dGV.Update();

            deltomain1.dGV.Refresh();

            deltomain1.ShowDialog();

            this.Close();


        }

        private void lbNo5_Click(object sender, EventArgs e)
        {

        }
    }
}
