﻿using System;
using System.Windows.Forms;
using System.Data.Odbc;
using System.Data;


namespace kadai3_1
{
    public partial class pqsldb : Form
    {
        /// <summary>
        /// iniファイルからＤＢパスへのアクセス
        /// </summary>
            public pqsldb()
        {
            InitializeComponent();

            dGV.AllowUserToAddRows = true;

            ControlBox = false;

        }

        public string pgsqlstr1 =
                                     "Dsn=PostgreSQL35Wkadai64;" +
                                     "Server =localhost;" +
                                     "Port = 5432;" +
                                     "User id=postgres;" +
                                     "Pwd=postgres;" +
                                     "DataBase=kaiin";
        public string[] listname ={"id", "gender", "job", "name"};

        /// <summary>
        ///postgresODBC経由での接続設定:データの自動読み込み
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pqsldb_Load(object sender, EventArgs e)
        {
            //gridにデータ表示：最新のものを表示
            dGV.Update();

            dGV.Refresh();

            DataSet pgconn5 = new DataSet();

            DataTable pgconn4 = new DataTable();

            pgconn5.Tables.Add(pgconn4);

            OdbcConnection pgconn1 = new OdbcConnection(pgsqlstr1);

            string sqlac1 = "select * from kaiin order by id asc";

            OdbcCommand pgconn2 = new OdbcCommand(sqlac1, pgconn1);

            OdbcDataAdapter pgconn3 = new OdbcDataAdapter(pgconn2);
            
            //ＳＱＬデータへのアクセス可否
            try
            {
                pgconn3.Fill(pgconn4);
            }
            catch (Exception)
            {
                MessageBox.Show("メインDBがありません", "要確認");

                btnAdd1.Enabled = false;
                btnChng1.Enabled = false;
                btnDel1.Enabled = false;
            }


            //SQL読み込み時，データ０件の場合

            OdbcConnection pgconn7 = new OdbcConnection(pgsqlstr1);

            string sqlac2 = "select count(id) from kaiin";

            OdbcCommand pgconn6 = new OdbcCommand(sqlac2, pgconn7);

            pgconn7.Open();

            string nocount = "0";

            nocount=Convert.ToString(pgconn6.ExecuteScalar());

            if (nocount =="0")
            {
                btnChng1.Enabled = false;
                btnDel1.Enabled = false;
            }

            pgconn1.Close();

            dGV.RowCount = pgconn4.Rows.Count + 1;
            
            for (int i = 0; i <= pgconn4.Rows.Count - 1; i++)
            {
                dGV.Rows[i].Cells[0].Value = pgconn4.Rows[i].Field<int>(listname[0]);

                dGV.Rows[i].Cells[1].Value = pgconn4.Rows[i].Field<string>(listname[1]);
                
                dGV.Rows[i].Cells[2].Value = pgconn4.Rows[i].Field<string>(listname[2]);
                
                dGV.Rows[i].Cells[3].Value = pgconn4.Rows[i].Field<string>(listname[3]);
            }

            //gridに行番号
            for (int j = 0; j < dGV.Rows.Count - 1; j++)
            {
                dGV.Rows[j].HeaderCell.Value = (j + 1).ToString();
            }
        }

        /// <summary>
        /// 追加フォームへ移動
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAdd1_Click(object sender, EventArgs e)
        {
            addform maintoadd1 = new addform();

                this.Visible = false;

                maintoadd1.Enabled = true;

                maintoadd1.Show();

                maintoadd1.Refresh();
        }

        /// <summary>
        /// 変更フォームへの移動
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnChng1_Click(object sender, EventArgs e)
        {
            changeform maintochng1 = new changeform();

            this.Visible = false;

            maintochng1.Enabled = true;


            maintochng1.Show();

            maintochng1.Refresh();
        }

        
        /// <summary>
        /// 削除フォームへの移動
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnDel1_Click(object sender, EventArgs e)
        {

            delForm maintodel1 = new delForm();

                    this.Visible = false;

                    maintodel1.Enabled = true;

                    maintodel1.Show();

                    maintodel1.Refresh();
        }

        /// <summary>
        /// 各種ボタン：操作不要
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void dGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void btnClose_Click(object sender, EventArgs e)
        {

            Application.Exit();
        }
    }
}

