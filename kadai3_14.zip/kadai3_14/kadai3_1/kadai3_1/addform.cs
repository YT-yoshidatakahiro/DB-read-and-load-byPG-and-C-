﻿using System;
using System.Windows.Forms;
using System.Data.Odbc;
using System.Data;
using System.Text.RegularExpressions;



namespace kadai3_1
{

    public partial class addform : Form
    {
        public addform()
        {
            InitializeComponent();

            tbName.Click += new EventHandler(tbName_Click);

            tbName.KeyPress += new KeyPressEventHandler(tbName_Keypress);



            ControlBox = false;


        }


        /// <summary>
        /// 追加フォーム起動：ナンバリング・性別・職業リスト一覧をコンボボックスに設定
        /// /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void addform_Load(object sender, EventArgs e)
        {
            pqsldb addtomain1 = new pqsldb();

            //性別コンボボックスリスト
            try
            {
                OdbcConnection gencmb1 = new OdbcConnection(addtomain1.pgsqlstr1);

                string cmbac1 = "select * from gender";

                OdbcCommand gencmb2 = new OdbcCommand(cmbac1, gencmb1);

                OdbcDataAdapter gencmb3 = new OdbcDataAdapter(gencmb2);

                DataTable gencmb4 = new DataTable();


                gencmb3.Fill(gencmb4);

                DataRow gencmb5 = gencmb4.NewRow();
                gencmb5[0] = -1;

                gencmb5[1] = "";

                gencmb4.Rows.InsertAt(gencmb5, 0);

                gencmb4.AcceptChanges();

                cmbGen1.DisplayMember = "gender";

                cmbGen1.ValueMember = "id";

                cmbGen1.Enabled = true;

                cmbGen1.DataSource = gencmb4;
            }
            catch (Exception)
            {
                MessageBox.Show("性別DBがありません", "DB確認");
                cmbGen1.Enabled = false;
                cmbJob1.Enabled = false;
                tbName.Enabled = false;
                btnAdd2.Enabled = false;

            }

            //職業コンボボックスリスト
            try
            {
                OdbcConnection jobcmb1 = new OdbcConnection(addtomain1.pgsqlstr1);

                string jobac1 = "select * from job";

                OdbcCommand jobcmb2 = new OdbcCommand(jobac1, jobcmb1);

                OdbcDataAdapter jobcmb3 = new OdbcDataAdapter(jobcmb2);

                DataTable jobcmb4 = new DataTable();


                jobcmb3.Fill(jobcmb4);

                DataRow jobcmb5 = jobcmb4.NewRow();

                jobcmb5[0] = -1;

                jobcmb5[1] = "";

                jobcmb4.Rows.InsertAt(jobcmb5, 0);

                jobcmb4.AcceptChanges();

                cmbJob1.DisplayMember = "job";

                cmbJob1.ValueMember = "id";

                cmbJob1.Enabled = true;

                cmbJob1.DataSource = jobcmb4;
            }
            catch (Exception)
            {
                MessageBox.Show("職業DBがありません", "DB確認");
                cmbGen1.Enabled = false;
                cmbJob1.Enabled = false;
                tbName.Enabled = false;
                btnAdd2.Enabled = false;

            }

            cmbJob1.Enabled = false;
            tbName.Enabled = false;
            btnAdd2.Enabled = false;

            //登録番号の表示
            addtomain1 = new pqsldb();

            OdbcConnection adconn1 = new OdbcConnection(addtomain1.pgsqlstr1);

            string sqlac0 = @"select count(id) from kaiin";

            string sqlac1 = @"select max(id) from kaiin";


            OdbcCommand adconn2 = new OdbcCommand(sqlac0, adconn1);

            OdbcCommand adconn3 = new OdbcCommand(sqlac1, adconn1);


                adconn1.Open();

                if (Convert.ToInt32(adconn2.ExecuteScalar()) >= 1)
                {
                    lbNoDisp.Text = Convert.ToString(Convert.ToInt32(adconn3.ExecuteScalar()) + 1);
                }
                else
                {
                    lbNoDisp.Text = "1";
                }

                adconn1.Close();
        }

        private void tbName_Keypress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && (e.KeyChar != '\b') && (e.KeyChar != '　'))
            {
                e.Handled = true;
            }
        }

        /// <summary>
        /// 性別・職業・氏名の入力規則
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cmbGen1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbGen1.Text != "")
            {
                cmbJob1.Enabled = true;
            }
            else 
            {
                cmbJob1.Enabled = false;
                tbName.Enabled = false;
                btnAdd2.Enabled = false;
            }
        }
        private void cmbJob1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbJob1.Text != "")
            {
                tbName.Enabled = true;
            }
            else 
            {
                tbName.Enabled = false;
                btnAdd2.Enabled = false;
            }

        }

        private static int CountChar(string str, string ch)
        {
            return str.Length - str.Replace(ch.ToString(), "").Length;
        }

        private void tbName_TextChanged(object sender, EventArgs e)
        {
            tbName.SelectionStart = tbName.Text.Length;

            Regex onlyhira1 = new Regex(@"[a-z]");
            Regex onlyhira2 = new Regex(@"[A-Z]");
            Regex onlyhira3 = new Regex(@"[ａ-ｚ]");
            Regex onlyhira4 = new Regex(@"[Ａ-Ｚ]");

            tbName.Text = onlyhira1.Replace(tbName.Text, "");
            tbName.Text = onlyhira2.Replace(tbName.Text, "");
            tbName.Text = onlyhira3.Replace(tbName.Text, "");
            tbName.Text = onlyhira4.Replace(tbName.Text, "");

            if (tbName.Text.StartsWith("　"))
            {
                tbName.Text = "";
                MessageBox.Show("氏名は全角入力 \n " +
                                    "氏名の間には全角スペース \n " +
                                        "氏名の前後に全角スペース入力不可");

                btnAdd2.Enabled = false;
            }
            else if (CountChar(tbName.Text, "　") >= 2)
            {
                MessageBox.Show("氏名は全角入力 \n " +
                                    "氏名の間には全角スペース \n " +
                                        "氏名の前後に全角スペース入力不可");

                tbName.Text = tbName.Text.Remove(tbName.Text.Length - 1, 1);

                btnAdd2.Enabled = false;
            }
            else if (Regex.IsMatch(tbName.Text, "[　]+."))
            {
                btnAdd2.Enabled = true;
            }
            else
            {
                btnAdd2.Enabled = false;
            }
        }

        private void tbName_Click(object sender, EventArgs e)
        {
            if (!tbName.Text.Equals(""))
            {
                btnAdd2.Enabled = true;
            }
            else
            {
                btnAdd2.Enabled = false;

            }
        }

        /// <summary>
        /// キャンセル：フォームを閉じる
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCan1_Click(object sender, EventArgs e)
        {
            pqsldb addtomain1 = new pqsldb();

            addtomain1.dGV.Refresh();

            addtomain1.dGV.Update();

            this.Refresh();

            this.Visible = false;

            addtomain1.Show();
        }

        /// <summary>
        /// 追加ボタン：メインデータリストへ一行追加
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAdd2_Click(object sender, EventArgs e)
        {
            pqsldb addtomain1 = new pqsldb();


            //入力が完全な場合:1行追加し，閉じる
            OdbcConnection adconn1 = new OdbcConnection(addtomain1.pgsqlstr1);

            string sqlac0 = @"create table  kaiin(id int, gender text,job text,name text)";

            string sqlac1 = @"insert into kaiin(id, gender,job,name) values(?,?,?,?)";

            OdbcCommand adconn2 = new OdbcCommand(sqlac1, adconn1);

            adconn2.Parameters.Add(new OdbcParameter("@id", Convert.ToInt32(lbNoDisp.Text)));

            adconn2.Parameters.Add(new OdbcParameter("@gender", cmbGen1.Text));

            adconn2.Parameters.Add(new OdbcParameter("@job", cmbJob1.Text));

            adconn2.Parameters.Add(new OdbcParameter("@name", tbName.Text));

            adconn1.Open();

            adconn2.ExecuteNonQuery();

            adconn1.Close();

            addtomain1.dGV.Refresh();

            addtomain1.dGV.Update();

            this.Refresh();

            this.Visible = false;

            tbName.Text = "";

            addtomain1.Show();
        }
        /// <summary>
        /// 各種ラベル:設定なし
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void lbNoDisp_Click(object sender, EventArgs e)
        {
        }
        private void lbNo1_Click(object sender, EventArgs e)
        {
        }
        private void lbGen1_Click(object sender, EventArgs e)
        {
        }
        private void lbJob1_Click(object sender, EventArgs e)
        {
        }
        private void lbName1_Click(object sender, EventArgs e)
        {
        }


        private void genderBindingSource_CurrentChanged(object sender, EventArgs e)
        {
        }
    }
}
